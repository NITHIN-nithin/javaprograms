package com.vehicle;

public class car extends Thread {
	public static String variable = "toyota";
	public static String floar = "2500 cc";
	public static String thala = "petrol";

	public static void main(String[] args) {
		car Thread = new car();
		Thread.start();
		System.out.println(variable);

		System.out.println(floar);

		System.out.println(thala);

	}

	public void run() {

	}

}
