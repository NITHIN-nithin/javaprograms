package com.BubbleSort;

public class bubblesort {

	public static void main(String s[]) {

		// int ar[]=new int[10];

		int a[] = { 1, 2, 3, 5, 4, 3 };

		for (int i = 0; i < a.length; i++) {

			for (int j = i + 1; j < a.length; j++) {
				int temp;
				if (a[i] > a[j])

				{
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}

		}

		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
	}
}