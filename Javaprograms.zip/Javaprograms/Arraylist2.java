package com.collectionframework2;

import java.util.ArrayList;

public class Arraylist2 {
	
	public static void main(String s[]) {
		
		
		ArrayList<String> ar=new ArrayList<String>();
		ar.add("Nithin"); ar.add("Darshan"); ar.add("vishal"); ar.add("santhosh");
		
		
		
		
		System.out.println(ar);
		
		ar.remove(3);
		
		System.out.println(ar);
		System.out.println(ar.size());
		
		
	}

}
