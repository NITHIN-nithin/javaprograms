package com.santhosh;

abstract class Main1 {

	public abstract void animalSound();

	public void sleep() {
		System.out.println("zzz");
	}

}

class Pig extends Main1 {
	public void animalSound() {
		System.out.println("The pig says: weee weee");

	}
}

class Main {
	public static void main(String[] args) {
		Pig myPig = new Pig();

		myPig.animalSound();
		myPig.sleep();
	}
}
     