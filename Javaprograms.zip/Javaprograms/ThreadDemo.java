package com.thala;

class Thread1 extends Thread {

	public void run() {
		for (int i = 0; i <= 100; i++) {

			System.out.println("Thread1 : " + i);

		}
	}
}

class Thread2 extends Thread {
	public void run() {
		for (int i = 200; i <= 300; i++) {

			System.out.println("Thread2 : " + i);

		}
	}
}

public class ThreadDemo {

	public static void main(String s[]) throws InterruptedException {

		System.out.println("Helo world");

		Thread1 ob1 = new Thread1();

		Thread2 ob2 = new Thread2();
		ob1.start();
		//ob1.join();
		ob2.start();
	}

}
