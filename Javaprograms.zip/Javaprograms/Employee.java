package com.employee;

import java.util.Scanner;

public class Employee {
	int id;
	String name;
	int sal;
	Scanner s2;

	public Employee(Scanner s1) {
		s2 = s1;
	}

	public void setEmp1() {

		Scanner s1 = new Scanner(System.in);
		System.out.println("Enter ID:-");
		id = Integer.parseInt(s1.nextLine());
		System.out.println("");
		

		System.out.println("Enter name:-");
		name = s1.nextLine();
		System.out.println("");
		
		System.out.println("Enter salary:-");
		sal = Integer.parseInt(s1.nextLine());


	}

	public void display() {
		System.out.println("ID=" + id);
		System.out.println("Name=" + name);
		System.out.println("Salary=" + sal);

	}

	public static void main(String a[]) {
		Scanner s1 = new Scanner(System.in);
		Employee obj = new Employee(s1);
		obj.setEmp1();
		obj.display();
	}

}
