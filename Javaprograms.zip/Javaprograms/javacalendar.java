package com.calendar;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class javacalendar {
	public static void main(String[] args) 
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the Year : ");
		int selectedYear = scn.nextInt();
		System.out.println();
		System.out.println("Enter the Month : ");
		int selectMonth =scn.nextInt() - 1;
		Calendar cal = new GregorianCalendar();
		int cDay = cal.get(Calendar.DATE);
		int cMonth = cal.get(Calendar.MONTH);
		int cYear = cal.get(Calendar.YEAR);

		GregorianCalendar gCal = new GregorianCalendar(selectedYear, selectMonth, 1);
		int days = gCal.getActualMaximum(Calendar.DATE);
		int startInweek = gCal.get(Calendar.DAY_OF_WEEK);

		gCal = new GregorianCalendar(selectedYear, selectMonth, days);
		int totalweeks = gCal.getActualMaximum(Calendar.WEEK_OF_MONTH);

		int count = 1;
		String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		System.out.println();
		System.err.println(months[selectMonth]+"-"+selectedYear);
		System.out.println();
		System.out.println(months[selectMonth]);
		
		System.out.println("SUN MON TUE WED THU FRI SAT");
		for (int i = 1; i <= totalweeks;i++ ) {
			System.out.println();
			for (int j = 1; j <= 7; j++) {
				if (count < startInweek || (count - startInweek + 1) > 31) {
					System.out.println("__");
					System.out.println(" ");

				} else {
					if (cDay == (count - startInweek + 1) && cMonth == selectMonth && cYear == selectedYear) {

						System.out.println("'" + getDay((count - startInweek + 1)) + "'");
						System.out.println(" ");
					} else {
						System.out.println(getDay((count - startInweek + 1)));
						System.out.println(" ");

					}

				}
				count++;
			}

		}

	}

	private static String getDay(int i) {
		String sDate = Integer.toString(i);
		if (sDate.length() == 1) {
			sDate = "0" + sDate;
			return sDate;
		}

		return sDate;
	}

}
