package com.thala;

public class casting extends Thread {
	public static int amount = 100;

	public static void main(String[] args) {
		casting thread = new casting();
		thread.start();
		System.out.println(amount);
		amount++;
		System.out.println(amount);
	}

	public void run() {
		amount++;
	}

}
