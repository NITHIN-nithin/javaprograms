package com.LinearSearch;

public class linearsearch {
	
	public static void main(String s[]) {
		
		int a[]= {1,2,3,4,5,6,7};
		int key = 8;
		
		boolean flag=false;
		
		for(int i=0; i<a.length;i++) {
			if(a[i]==key) {
				flag = true;
				
				break;
			}
		}
		if(flag) {
			System.out.println("Element found");
		}
		else
		{
			System.out.println("Element not found");
		}
		
	}

}
