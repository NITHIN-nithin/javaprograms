package com.collectionframework;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String s[]) {

		
		
		
		//Array list, what . how to use
		
		ArrayList<Integer> ar=new ArrayList<Integer>();
		ar.add(10);
		ar.add(30);
		ar.add(40);
		ar.add(50);
		System.out.println(ar.size());	
	}

}
