package com.operators;

public class operators {
	public static void main(String[] args) {

		int k = 8;

		if (k % 3 == 0 || k % 4== 0) {
			System.out.println("k is divided by 3 ");
		} else {

			System.out.println("k is divided by 4");
		}

		
                                                                   		
	}

}
